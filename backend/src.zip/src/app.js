import express from "express";
import cors from "cors";
import subscriptionRoutes from "./routes/subscription.routes.js";
import authRoutes from "./routes/auth.routes.js";

const app = express();

app.disable("x-powered-by");

const allowedOrigins = [process.env.FRONTEND_URL].filter(Boolean);

app.use(
  cors({
    origin: allowedOrigins,
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE"],
    allowedHeaders: ["Content-Type", "Authorization"],
  }),
);

app.use(express.json({ limit: "100kb" }));

app.get("/api/health", (req, res) => {
  res.status(200).json({
    status: "OK",
    message: "EXE Promotion API is running",
  });
});

app.use("/api/auth", authRoutes);

app.use("/api/subscriptions", subscriptionRoutes);

app.use((req, res) => {
  res.status(404).json({
    message: "Route not found",
  });
});

export default app;
